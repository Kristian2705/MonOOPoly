#pragma once
class Monopoly
{
};

