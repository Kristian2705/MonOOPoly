#include <iostream>

int main()
{
    std::cout << "Hello MonOOPoly!" << std::endl;
}
