#pragma once
class Trade
{
};

