#pragma once
class Card
{
};

