#pragma once
class Board
{
};

