#pragma once
class GroupPaymentCard
{
};

